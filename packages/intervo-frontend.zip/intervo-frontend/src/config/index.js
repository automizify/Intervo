export const ALLOWED_ADMIN_DOMAINS = [
  "codedesign.app",
  "codedesign.ai",
  "intervo.ai",
];
