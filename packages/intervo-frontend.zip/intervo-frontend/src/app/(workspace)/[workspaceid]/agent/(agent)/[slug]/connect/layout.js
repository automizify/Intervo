export const metadata = {
  title: "Intervo.ai - Connect & Widget Settings",
};

export default function ConnectLayout({ children }) {
  return <>{children}</>;
}
