export const metadata = {
  title: "Studio", // This will become "Intervo - Studio"
};

export default function StudioLayout({ children }) {
  return <>{children}</>;
}
